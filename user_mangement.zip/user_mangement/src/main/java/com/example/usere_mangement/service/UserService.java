package com.example.usere_mangement.service;

import com.example.usere_mangement.dto.UserRegistrationDto;
import com.example.usere_mangement.model.AppUser;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {

  AppUser save(UserRegistrationDto registrationDto);
}
